exports.handler = async () => ({
  statusCode: 200,
  body: JSON.stringify({ message: "stub - awaiting real deployment via CI" }),
});
